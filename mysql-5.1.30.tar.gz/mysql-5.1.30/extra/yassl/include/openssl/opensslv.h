/* opensslv.h compatibility */

#ifndef yaSSL_opensslv_h__
#define yaSSL_opensslv_h__


/* api version compatibility */
#define OPENSSL_VERSION_NUMBER 0x0090700f


#endif /* yaSSLopensslv_h__ */

