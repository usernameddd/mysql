/* hmac.h  for openvpn */
